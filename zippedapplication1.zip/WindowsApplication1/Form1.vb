﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports CrystalDecisions.CrystalReports.Engine

Public Class Registration_form


    Private Sub Registration_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EducationDataSet.studentinfo3' table. You can move, or remove it, as needed.
        Me.Studentinfo3TableAdapter.Fill(Me.EducationDataSet.studentinfo3)

    End Sub

    Private Sub Buttonsubmit_Click(sender As Object, e As EventArgs) Handles Buttonsubmit.Click
        Dim a As Integer
        If RadioXI.Checked Then
            a = 11
        Else : a = 12
        End If
        Dim b As String = String.Empty
        If Chkread.Checked Then
            b &= " reading"
        End If
        If Chksing.Checked Then
            b &= " singing"
        End If
        If Chkmusic.Checked Then
            b &= " music"
        End If
        If Chkdance.Checked Then
            b &= " dance"

        End If


        Dim query As String = String.Empty
        query &= "insert into studentinfo3(name,stream,dob,hobby,class,address,phoneno)"

        query &= "VALUES (@colName,@colstream, @coldob, @colhobby,@colclass, @coladdress,@colphone)"

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Using comm As New SqlCommand()
                With comm
                    .Connection = conn
                    .CommandType = CommandType.Text
                    .CommandText = query
                    .Parameters.AddWithValue("@colName", Txtbname.Text)
                    .Parameters.AddWithValue("@colstream", Combostream.SelectedItem)
                    .Parameters.AddWithValue("@coldob", Datedob.Value)
                    .Parameters.AddWithValue("@colhobby", b)
                    .Parameters.AddWithValue("@colclass", a)
                    .Parameters.AddWithValue("@coladdress", Txtbaddress.Text)
                    .Parameters.AddWithValue("@colphone", Txtbphone.Text)

                End With
                Try
                    conn.Open()
                    comm.ExecuteNonQuery()

                Catch ex As SqlException
                    MessageBox.Show(ex.Message.ToString(), "Error Message")
                End Try
            End Using
        End Using

    End Sub



    Private Sub Bttnupdate_Click(sender As Object, e As EventArgs) Handles Bttnupdate.Click
        Dim a1 As Integer
        a1 = Txtupdateroll.Text

        Dim a2 As Integer
        If RadioXI.Checked Then
            a2 = 11
        Else : a2 = 12
        End If
        Dim b2 As String = String.Empty
        If Chkread.Checked Then
            b2 &= " reading"
        End If
        If Chksing.Checked Then
            b2 &= " singing"
        End If
        If Chkmusic.Checked Then
            b2 &= " music"
        End If
        If Chkdance.Checked Then
            b2 &= " dance"

        End If


        Dim query1 As String = String.Empty
        query1 &= "update studentinfo3 "
        query1 &= "set name=@n ,stream=@s ,dob=@d ,hobby=@h ,class=@c ,address=@a ,phoneno=@p "
        query1 &= "where roll_no=@v"

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Using comm As New SqlCommand()
                With comm
                    .Connection = conn
                    .CommandType = CommandType.Text
                    .CommandText = query1
                    .Parameters.AddWithValue("@n", Txtbname.Text)
                    .Parameters.AddWithValue("@s", Combostream.SelectedItem)
                    .Parameters.AddWithValue("@d", Datedob.Value)
                    .Parameters.AddWithValue("@h", b2)
                    .Parameters.AddWithValue("@c", a2)
                    .Parameters.AddWithValue("@a", Txtbaddress.Text)
                    .Parameters.AddWithValue("@p", Txtbphone.Text)
                    .Parameters.AddWithValue("@v", a1)

                End With
                Try
                    conn.Open()
                    comm.ExecuteNonQuery()

                Catch ex As SqlException
                    MessageBox.Show(ex.Message.ToString(), "Error Message")
                End Try
            End Using
        End Using


    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click
        Dim a4 As Integer
        a4 = Txtupdateroll.Text

        Dim query2 As String = String.Empty
        query2 &= "delete from  studentinfo3 where roll_no=@ras"

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Using comm As New SqlCommand()
                With comm
                    .Connection = conn
                    .CommandType = CommandType.Text
                    .CommandText = query2
                    .Parameters.AddWithValue("@ras", a4)
                    

                End With
                Try
                    conn.Open()
                    comm.ExecuteNonQuery()

                Catch ex As SqlException
                    MessageBox.Show(ex.Message.ToString(), "Error Message")
                End Try
            End Using
        End Using


    End Sub

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load


Public Class Form1
    Private Sub Button1_Click(ByVal sender As System.Object,
    ByVal e As System.EventArgs) Handles Button1.Click
        Dim cryRpt As New ReportDocument
        cryRpt.Load("PUT CRYSTAL REPORT PATH HERE\CrystalReport1.rpt")
        CrystalReportViewer1.ReportSource = cryRpt
        CrystalReportViewer1.Refresh()
    End Sub
End Class

    End Sub
End Class
